# _*_ coding:utf-8 _*_
__author__ = 'JiangKui'
__date__ = '2018/1/3 12:44'
"""

    百度api成功调用脚本

"""
import urllib, sys
import json
from aip import AipOcr

def serviceSetup(APP_ID = '10618664',API_KEY = 's37kdgQPRKnSFmdjgwFnTXrl', SECRET_KEY = 'cV9SvMl0gaVjGxTik7qH28kBb36bkS8G'):
    #定义常量
    # APP_ID = '10618664'
    # API_KEY = 's37kdgQPRKnSFmdjgwFnTXrl'
    # SECRET_KEY = 'cV9SvMl0gaVjGxTik7qH28kBb36bkS8G'
    #
    #初始化对象
    client = AipOcr(APP_ID, API_KEY, SECRET_KEY)
    return client

def access_token():
    APP_ID = '10618664'
    API_KEY = 's37kdgQPRKnSFmdjgwFnTXrl'
    SECRET_KEY = 'cV9SvMl0gaVjGxTik7qH28kBb36bkS8G'
#    return APP_ID,API_KEY,SECRET_KEY


    # client_id 为官网获取的AK， client_secret 为官网获取的SK
    host = 'https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id='+API_KEY+'&client_secret='+SECRET_KEY
    request = urllib.Request(host)
    request.add_header('Content-Type', 'application/json; charset=UTF-8')
    response = urllib.urlopen(request)
    content = json.loads(response.read())

    if (content):
        #print (content),type(content)
        return content.get("access_token")

#print tokenParas()

